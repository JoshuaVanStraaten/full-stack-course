import React, { useState } from "react";
import Header from "./Header";
import Footer from "./Footer";
import Note from "./Note";
import CreateArea from "./CreateArea";

function App() {
  const [notesArray, setNotesArray] = useState([
    { title: "Note title", content: "Note content" },
  ]);

  function addNote(note) {
    setNotesArray((prevNoteArray) => {
      return [...prevNoteArray, note];
    });
  }

  function delNote(id) {
    setNotesArray((prevNoteArray) => {
      return prevNoteArray.filter((item, index) => index !== id);
    });
  }

  return (
    <div>
      <Header />
      <CreateArea addNote={addNote} />
      {notesArray.map((notes, index) => (
        <Note
          key={index}
          id={index}
          title={notes.title}
          content={notes.content}
          delNote={delNote}
        />
      ))}
      <Footer />
    </div>
  );
}

export default App;
