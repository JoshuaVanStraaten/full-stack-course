import React, { useState } from "react";

function App() {
  let time = new Date().toLocaleTimeString("en-US", { hour12: false });
  const [currentTime, setTime] = useState(time);

  function getCurrentTime() {
    time = new Date().toLocaleTimeString("en-US", { hour12: false });
    setTime(time);
  }

  setInterval(getCurrentTime, 1000);

  return (
    <div className="container">
      <h1>{currentTime}</h1>
      <button onClick={getCurrentTime}>Get Time</button>
    </div>
  );
}

export default App;
